// TGHMod  (C++ ASI, 基于 Aru 的 GTA IV ScriptHook SDK)
//
// 按键：
//   T  灵魂出窍：Niko 原地冻结，镜头脱离，自由飞行
//   G  附身：镜头对准的 NPC 倒地抽搐 1.8 秒，然后由你操控
//   H  返回 Niko
//
// 灵魂状态：W/S/A/D 移动，Space 升，C 降，Shift 加速，Q/E 左右转，R/F 抬头/低头
// 附身状态：W/S/A/D 相对镜头方向移动（Shift 跑），Q/E 转镜头
//
// 说明：这个 SDK 没有"把玩家变成另一个 NPC"的接口，所以附身 = 镜头跟随 + 脚本给 NPC 下移动指令。
// 运行时会在游戏目录写 TGHMod.log，出问题把它发给我。

#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdarg.h>

#include "ScriptHook/ScriptHookManager.h"
#include "ScriptHook/NativeFiberThread.h"
#include "ScriptHook/Scripting.h"

using namespace Scripting;                 // ScriptingDirty.h 里直接用了 ScriptAny，必须先有这一行

#include "ScriptHook/ScriptingDirty.h"

// ---------------- 可调参数 ----------------
static const u32 CONVULSE_MS    = 1800;   // 抽搐时长
static const f32 SHAKE_FORCE    = 0.35f;  // 抽搐时每次施加的小力（太猛/没反应就改这个）
static const u32 SHAKE_EVERY_MS = 120;    // 抽搐施力间隔
static const f32 SPIRIT_SPEED   = 0.35f;  // 灵魂镜头每帧移动距离
static const f32 PICK_RADIUS    = 5.0f;   // 选目标：镜头视线落点附近多少米内找人
static const f32 FOLLOW_DIST    = 5.0f;   // 附身后镜头距离
static const f32 FOLLOW_HEIGHT  = 2.2f;   // 附身后镜头高度
static const u32 MOVE_EVERY_MS  = 200;    // 每隔多久给 NPC 下一次移动指令

static const f32 PI_F = 3.14159265f;

// ---------------- 日志 ----------------
static void LogMsg(const char *fmt, ...)
{
    FILE *f = fopen("TGHMod.log", "a");
    if (!f) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    fprintf(f, "[%02d:%02d:%02d] ", st.wHour, st.wMinute, st.wSecond);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fprintf(f, "\n");
    fclose(f);
}

// 屏幕左下角提示
static void ShowText(const char *text, u32 ms)
{
    PrintStringWithLiteralStringNow("STRING", text, ms, 1);
}

// ---------------- 输入 ----------------
static bool GameFocused()
{
    HWND h = GetForegroundWindow();
    if (!h) return false;
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    return pid == GetCurrentProcessId();
}

static bool KeyDown(int vk)
{
    return GameFocused() && (GetAsyncKeyState(vk) & 0x8000) != 0;
}

// 只在按下的那一帧返回 true（每个键每帧只调用一次）
static bool Pressed(int vk)
{
    static bool prev[256] = { false };
    bool now = KeyDown(vk);
    bool r = now && !prev[vk & 255];
    prev[vk & 255] = now;
    return r;
}

// ---------------- 状态 ----------------
enum Mode { MODE_IDLE, MODE_SPIRIT, MODE_CONVULSE, MODE_POSSESSED };

class TGHThread : public NativeFiberThread
{
private:
    Mode   m_mode;
    Player m_player;
    Ped    m_niko;
    Ped    m_target;
    Camera m_cam;
    bool   m_camOn;

    f32 m_camX, m_camY, m_camZ;
    f32 m_yaw, m_pitch;     // 弧度，yaw=0 朝北(+Y)
    f32 m_groundZ;

    u32 m_convulseEnd;
    u32 m_nextShake;
    u32 m_nextMove;
    bool m_wasMoving;
    u32 m_rng;

    f32 Rand01()
    {
        m_rng = m_rng * 1664525u + 1013904223u;
        return (f32)((m_rng >> 8) & 0xFFFF) / 65535.0f;
    }

    bool Alive(Ped p)
    {
        return p != 0 && DoesCharExist(p) && !IsCharDead(p);
    }

    // ---- 镜头 ----
    void CamStart()
    {
        if (m_camOn) return;
        CreateCam(14, &m_cam);
        SetCamPos(m_cam, m_camX, m_camY, m_camZ);
        CamLookAhead();
        ScriptingDirty::ActivateScriptedCams(1, 1);
        SetCamActive(m_cam, true);
        SetCamPropagate(m_cam, true);
        m_camOn = true;
    }

    void CamStop()
    {
        if (!m_camOn) return;
        SetCamActive(m_cam, false);
        SetCamPropagate(m_cam, false);
        ScriptingDirty::ActivateScriptedCams(0, 0);
        DestroyCam(m_cam);
        m_camOn = false;
    }

    void CamDir(f32 *dx, f32 *dy, f32 *dz)
    {
        f32 cp = cosf(m_pitch);
        *dx = -sinf(m_yaw) * cp;
        *dy = cosf(m_yaw) * cp;
        *dz = sinf(m_pitch);
    }

    // 镜头看向自己前方（自由飞行用）
    void CamLookAhead()
    {
        f32 dx, dy, dz;
        CamDir(&dx, &dy, &dz);
        NativeInvoke::Invoke<ScriptVoid>("POINT_CAM_AT_COORD", m_cam,
            m_camX + dx * 10.0f, m_camY + dy * 10.0f, m_camZ + dz * 10.0f);
    }

    // 镜头跟随目标（附身用）
    void CamFollow(Ped p)
    {
        f32 x, y, z;
        GetCharCoordinates(p, &x, &y, &z);
        f32 fx = -sinf(m_yaw), fy = cosf(m_yaw);
        m_camX = x - fx * FOLLOW_DIST;
        m_camY = y - fy * FOLLOW_DIST;
        m_camZ = z + FOLLOW_HEIGHT;
        SetCamPos(m_cam, m_camX, m_camY, m_camZ);
        NativeInvoke::Invoke<ScriptVoid>("POINT_CAM_AT_COORD", m_cam, x, y, z + 0.8f);
    }

    void RotateByKeys(bool allowPitch)
    {
        const f32 rot = 0.04f;
        if (KeyDown('Q')) m_yaw += rot;
        if (KeyDown('E')) m_yaw -= rot;
        if (allowPitch)
        {
            if (KeyDown('R')) m_pitch += rot;
            if (KeyDown('F')) m_pitch -= rot;
            if (m_pitch > 1.4f) m_pitch = 1.4f;
            if (m_pitch < -1.4f) m_pitch = -1.4f;
        }
    }

    // ---- T：灵魂出窍 ----
    void SpiritOn()
    {
        if (m_mode != MODE_IDLE) return;

        m_player = ConvertIntToPlayerIndex(GetPlayerId());
        m_niko = 0;
        GetPlayerChar(m_player, &m_niko);
        if (!Alive(m_niko))
        {
            LogMsg("SpiritOn: 没有取到有效的 Niko");
            return;
        }

        f32 x, y, z, h = 0.0f;
        GetCharCoordinates(m_niko, &x, &y, &z);
        GetCharHeading(m_niko, &h);

        m_yaw = h * PI_F / 180.0f;
        m_pitch = -0.35f;
        m_camX = x; m_camY = y; m_camZ = z + 3.0f;
        m_groundZ = z - 1.0f;

        SetPlayerControl(m_player, false);
        FreezeCharPosition(m_niko, true);
        CamStart();

        m_mode = MODE_SPIRIT;
        LogMsg("灵魂出窍 niko=%d pos=%.1f,%.1f,%.1f", (int)m_niko, x, y, z);
        ShowText("TGH: spirit mode - aim at a person, press G. H to return.", 4000);
    }

    void UpdateSpirit()
    {
        if (!Alive(m_niko)) { ReturnToNiko(); return; }

        RotateByKeys(true);

        f32 fx = -sinf(m_yaw), fy = cosf(m_yaw);
        f32 rx = cosf(m_yaw),  ry = sinf(m_yaw);
        f32 sp = SPIRIT_SPEED * (KeyDown(VK_SHIFT) ? 3.0f : 1.0f);

        if (KeyDown('W')) { m_camX += fx * sp; m_camY += fy * sp; }
        if (KeyDown('S')) { m_camX -= fx * sp; m_camY -= fy * sp; }
        if (KeyDown('D')) { m_camX += rx * sp; m_camY += ry * sp; }
        if (KeyDown('A')) { m_camX -= rx * sp; m_camY -= ry * sp; }
        if (KeyDown(VK_SPACE)) m_camZ += sp;
        if (KeyDown('C'))      m_camZ -= sp;

        SetCamPos(m_cam, m_camX, m_camY, m_camZ);
        CamLookAhead();
    }

    // ---- G：附身 ----
    bool FindTarget(Ped *out)
    {
        f32 dx, dy, dz;
        CamDir(&dx, &dy, &dz);

        // 视线落点：往下看时取视线与地面的交点，否则取前方 12 米
        f32 t = 12.0f;
        if (dz < -0.05f)
        {
            t = (m_camZ - m_groundZ) / (-dz);
            if (t < 3.0f) t = 3.0f;
            if (t > 40.0f) t = 40.0f;
        }
        f32 px = m_camX + dx * t;
        f32 py = m_camY + dy * t;
        f32 pz = m_camZ + dz * t;

        Ped cand = 0;
        GetClosestChar(px, py, pz, PICK_RADIUS, true, false, &cand);

        if (cand == 0 || cand == m_niko) return false;
        if (!Alive(cand)) return false;
        *out = cand;
        return true;
    }

    void Possess()
    {
        if (m_mode != MODE_SPIRIT) return;

        Ped t = 0;
        if (!FindTarget(&t))
        {
            ShowText("TGH: no target. Aim the camera at a person.", 2500);
            LogMsg("Possess: 没找到目标");
            return;
        }

        m_target = t;
        ClearCharTasksImmediately(m_target);
        SetBlockingOfNonTemporaryEvents(m_target, true);
        SwitchPedToRagdoll(m_target, 10000, CONVULSE_MS, 0, 1, 1, 0);

        m_convulseEnd = GetTickCount() + CONVULSE_MS;
        m_nextShake = GetTickCount();
        m_wasMoving = false;
        m_mode = MODE_CONVULSE;
        LogMsg("附身目标 ped=%d，开始抽搐 %u ms", (int)m_target, (unsigned)CONVULSE_MS);
    }

    void UpdateConvulse()
    {
        if (!Alive(m_target)) { LogMsg("抽搐中目标失效"); ReturnToNiko(); return; }

        CamFollow(m_target);

        u32 now = GetTickCount();
        if ((i32)(now - m_nextShake) >= 0)
        {
            f32 fx = (Rand01() - 0.5f) * 2.0f * SHAKE_FORCE;
            f32 fy = (Rand01() - 0.5f) * 2.0f * SHAKE_FORCE;
            ApplyForceToPed(m_target, 3, fx, fy, 0.05f, 0.0f, 0.0f, 0.0f, 0, 0, 1, 1);
            m_nextShake = now + SHAKE_EVERY_MS;
        }

        if ((i32)(now - m_convulseEnd) >= 0)
        {
            SwitchPedToAnimated(m_target, true);
            ClearCharTasksImmediately(m_target);
            m_mode = MODE_POSSESSED;
            LogMsg("抽搐结束，进入操控");
            ShowText("TGH: possessed. WASD move, Shift run, Q/E turn, H return.", 4000);
        }
    }

    // ---- 附身后操控 ----
    void UpdatePossessed()
    {
        if (!Alive(m_target))
        {
            LogMsg("被附身目标失效，返回");
            ShowText("TGH: target gone, returning.", 2000);
            ReturnToNiko();
            return;
        }

        RotateByKeys(false);
        CamFollow(m_target);

        f32 f = (KeyDown('W') ? 1.0f : 0.0f) - (KeyDown('S') ? 1.0f : 0.0f);
        f32 r = (KeyDown('D') ? 1.0f : 0.0f) - (KeyDown('A') ? 1.0f : 0.0f);

        if (f != 0.0f || r != 0.0f)
        {
            f32 fx = -sinf(m_yaw), fy = cosf(m_yaw);
            f32 rx = cosf(m_yaw),  ry = sinf(m_yaw);
            f32 dx = fx * f + rx * r;
            f32 dy = fy * f + ry * r;
            f32 len = sqrtf(dx * dx + dy * dy);
            dx /= len; dy /= len;

            u32 now = GetTickCount();
            if ((i32)(now - m_nextMove) >= 0)
            {
                f32 x, y, z;
                GetCharCoordinates(m_target, &x, &y, &z);
                u32 speed = KeyDown(VK_SHIFT) ? 4 : 2;   // 2=走 4=跑（和 ScriptHookDotNet 的 GoTo/RunTo 一致）
                TaskGoStraightToCoord(m_target, x + dx * 6.0f, y + dy * 6.0f, z, speed, (u32)-1);
                m_nextMove = now + MOVE_EVERY_MS;
            }
            m_wasMoving = true;
        }
        else if (m_wasMoving)
        {
            ClearCharTasks(m_target);
            m_wasMoving = false;
        }
    }

    // ---- H：返回 ----
    void ReturnToNiko()
    {
        if (m_mode == MODE_IDLE) return;

        if (m_target != 0 && DoesCharExist(m_target))
        {
            ClearCharTasks(m_target);
            SetBlockingOfNonTemporaryEvents(m_target, false);
        }
        CamStop();
        if (m_niko != 0 && DoesCharExist(m_niko))
        {
            FreezeCharPosition(m_niko, false);
        }
        SetPlayerControl(m_player, true);

        m_target = 0;
        m_wasMoving = false;
        m_mode = MODE_IDLE;
        LogMsg("已返回 Niko");
        ShowText("TGH: back to Niko.", 2000);
    }

protected:
    virtual void RunScript()
    {
        LogMsg("TGHMod 脚本线程启动");
        ShowText("TGHMod loaded. T = spirit, G = possess, H = return.", 5000);

        for (;;)
        {
            bool pT = Pressed('T');
            bool pG = Pressed('G');
            bool pH = Pressed('H');

            if (pT) SpiritOn();
            if (pG) Possess();
            if (pH) ReturnToNiko();

            switch (m_mode)
            {
            case MODE_SPIRIT:    UpdateSpirit();    break;
            case MODE_CONVULSE:  UpdateConvulse();  break;
            case MODE_POSSESSED: UpdatePossessed(); break;
            default: break;
            }

            Wait(0);
        }
    }

public:
    TGHThread()
        : NativeFiberThread(),
          m_mode(MODE_IDLE), m_player(0), m_niko(0), m_target(0), m_cam(0), m_camOn(false),
          m_camX(0), m_camY(0), m_camZ(0), m_yaw(0), m_pitch(0), m_groundZ(0),
          m_convulseEnd(0), m_nextShake(0), m_nextMove(0), m_wasMoving(false), m_rng(12345u)
    {
        SetName("TGHMod");
    }
};

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(hModule);
        LogMsg("TGHMod.asi 已加载（DllMain）");
        ScriptHookManager::RegisterThread(new TGHThread(), hModule);
    }
    return TRUE;
}
